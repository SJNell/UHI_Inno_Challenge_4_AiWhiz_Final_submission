from os import name
from django.urls import path
from . import views
urlpatterns = [
    path('', views.home,name="home"),
    path('getSuggestions',views.getSuggestions,name="getSuggestions"),
    path('getDiseasePrediction',views.getDiseasePrediction,name="getDiseasePrediction")
    
]