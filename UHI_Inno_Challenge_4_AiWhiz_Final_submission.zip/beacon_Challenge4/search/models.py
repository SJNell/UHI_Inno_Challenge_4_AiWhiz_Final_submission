from django.db import models
import csv
from fast_autocomplete.misc import read_csv_gen
from fast_autocomplete import AutoComplete
from django.conf import settings
import pickle
import pandas as pd
from django.db.models.base import Model

# Create your models here.
class Record(Model):
    class Meta:
        db_table = "Record"
    Record_ID     = models.AutoField(primary_key=True,null=False,db_column="Record_ID")
    DiseaseName  = models.CharField(max_length=150,null=False,db_column="DiseaseName")
    DiseaseSymptoms = models.CharField(max_length=1000,null=True,db_column="DiseaseSymptoms")
    DiseaseTreatment  = models.CharField(max_length=1000,null=True,db_column="DiseaseTreatment")
    DiseaseDiagnosis  = models.CharField(max_length=1000,null=True,db_column="DiseaseDiagnosis")

    def __str__(self):
        return self.DiseaseName


class DiseaseData(Model):
    class Meta:
        db_table = "DiseaseData"
    DiseaseData_ID     = models.AutoField(primary_key=True,null=False,db_column="DiseaseData_ID")
    DiseaseName  = models.CharField(max_length=150,null=False,db_column="DiseaseName")   
    Abdominal_pain = models.IntegerField(default=0,null=False)
    Abnormal_menstrual_cycle = models.IntegerField(default=0,null=False)
    Anal_itch = models.IntegerField(default=0,null=False)
    Blister_of_skin = models.IntegerField(default=0,null=False)
    Bloating_symptom = models.IntegerField(default=0,null=False)
    Body_ache = models.IntegerField(default=0,null=False)
    breathing_with_whistling_sound = models.IntegerField(default=0,null=False)
    Breathlessness = models.IntegerField(default=0,null=False)
    Chest_pain = models.IntegerField(default=0,null=False)
    Clouded_consciousness = models.IntegerField(default=0,null=False)
    Cough= models.IntegerField(default=0,null=False)
    Dizziness = models.IntegerField(default=0,null=False)
    Dyspnea = models.IntegerField(default=0,null=False)
    Dyspnoea = models.IntegerField(default=0,null=False)
    Dyspnoea_Breathlessness = models.IntegerField(default=0,null=False)
    Dysuria = models.IntegerField(default=0,null=False)
    Edema_of_lower_leg = models.IntegerField(default=0,null=False)
    Eruption_of_Skin = models.IntegerField(default=0,null=False)
    Eruption_of_Skin_Rashes = models.IntegerField(default=0,null=False)
    Eyes_sensitive_to_light = models.IntegerField(default=0,null=False)
    Fatigue = models.IntegerField(default=0,null=False)
    Feeling_bad = models.IntegerField(default=0,null=False)
    Fever = models.IntegerField(default=0,null=False)
    Fever_with_Chills = models.IntegerField(default=0,null=False)
    Hazy_vision = models.IntegerField(default=0,null=False)
    Headache = models.IntegerField(default=0,null=False)
    Heavy_breathing = models.IntegerField(default=0,null=False)
    Increased_frequency_of_urination  = models.IntegerField(default=0,null=False)
    Itching_of_skin = models.IntegerField(default=0,null=False)
    Itchy_skin_eruptions = models.IntegerField(default=0,null=False)
    Joint_Pain = models.IntegerField(default=0,null=False)
    Joint_Swelling = models.IntegerField(default=0,null=False)
    Left_sided_abdominal_pain = models.IntegerField(default=0,null=False)
    Left_right_sided_abdominal_pain = models.IntegerField(default=0,null=False)
    Loss_of_appetite = models.IntegerField(default=0,null=False)
    Muscle_Pain_Joint_Pain = models.IntegerField(default=0,null=False)
    Muscle_weakness_of_limb = models.IntegerField(default=0,null=False)
    Nausea = models.IntegerField(default=0,null=False)
    Negative_automatic_thoughts = models.IntegerField(default=0,null=False)
    Nose_running = models.IntegerField(default=0,null=False)
    Numbness_of_face_and_limbs = models.IntegerField(default=0,null=False)
    Pain_in_Pelvis = models.IntegerField(default=0,null=False)
    Painful_urination = models.IntegerField(default=0,null=False)
    Productive_cough = models.IntegerField(default=0,null=False)
    Productive_cough_with_sputum = models.IntegerField(default=0,null=False)
    Pruritic_rash = models.IntegerField(default=0,null=False)
    Pruritic_rash_Itchy_skin_eruptions = models.IntegerField(default=0,null=False)
    Pruritus_Ani = models.IntegerField(default=0,null=False)
    Pruritus_Ani_Anal_itch = models.IntegerField(default=0,null=False)
    Rashes = models.IntegerField(default=0,null=False)
    Rectal_Bleeding = models.IntegerField(default=0,null=False)
    Right_sided_abdominal_pain = models.IntegerField(default=0,null=False)
    sneezing = models.IntegerField(default=0,null=False)
    Thoughts_of_self_harm = models.IntegerField(default=0,null=False)
    Vertigo = models.IntegerField(default=0,null=False)
    Vomiting = models.IntegerField(default=0,null=False)
    weakness = models.IntegerField(default=0,null=False)
    Weight_loss = models.IntegerField(default=0,null=False)
    Wheezing = models.IntegerField(default=0,null=False)
    

    def __str__(self):
        return self.DiseaseName
    




class Suggestor():
    __instance = None
    autocomplete = None
    worldList = []
    @staticmethod 
    def getInstance():
        """ Static access method. """
        if Suggestor.__instance == None:
            Suggestor()
        return Suggestor.__instance

    def __init__(self):
        """ Virtually private constructor. """
        if Suggestor.__instance != None:
            raise Exception("This class is a singleton!")
        else:
            self.load_words()
            Suggestor.__instance = self

    def load_words(self):
        csv_gen = read_csv_gen(settings.WORD_FILE_PATH , csv_func=csv.DictReader)
        in_words = {}
        wordlist = []
        for line in csv_gen:
            local_words = line['symptom']            
            if local_words not in in_words:
                wordlist.append(local_words)
                in_words[local_words] = {}    
        self.worldList = wordlist 
        self.autocomplete = AutoComplete(words=in_words)

    def getWordList(self):
        return self.worldList

    def getSuggestion(self,word,max_c,size):
        return self.autocomplete.search(word=word, max_cost=max_c, size=size)



class DiseasePredictor():
    __instance = None
    model = None
    input_values = None
    diseaseData = []



    @staticmethod
    def getInstance():
        if DiseasePredictor.__instance == None:
            DiseasePredictor()
        return DiseasePredictor.__instance

    def __init__(self):
        if DiseasePredictor.__instance !=None:
            raise Exception("This class is singleton")
        else:
            self.loadmodel()
            self.loadData()
            DiseasePredictor.__instance = self

    def loadData(self):
        csv_gen = read_csv_gen(settings.DISEASE_DIAGNSIS_TREATMENT_FILE_PATH , csv_func=csv.DictReader)
        DiseaseData = []

        
        for line in csv_gen:
            DiseaseData.append({
                "name" : line['Common Diseases'],
                "investigations":line['Investigations'],
                "treatment":line['Treatment']
            })
        
        self.diseaseData = DiseaseData

    def getDeseaseInfo(self,id):
        return self.diseaseData[id]

        
    def loadmodel(self):        
        load_model_pkl = open(settings.DISEASE_MODEL_PICKLE_FILE_PATH, 'rb')
        self.model = pickle.load(load_model_pkl)
        self.input_values = pd.DataFrame({'Thoughts of self harm': [],'Eruption of Skin': [],'breathing with whistling sound': [],
                                    'Negative automatic thoughts': [],'Dyspnoea': [],'Increased frequency of urination': [],
                                    'Wheezing': [],'Rectal Bleeding': [],'Nausea': [],'Abnormal menstrual cycle': [],
                                    'Clouded consciousness': [],'Fatigue': [],'Body ache': [],'Productive cough': [],
                                    'Productive cough (with sputum)': [],'Fever': [],'Bloating symptom': [],
                                    'Eyes sensitive to light': [],'Pain in Pelvis': [],'Pruritus Ani': [],'Joint Pain': [],
                                    'Joint Swelling': [],'Itching of skin': [],'Abdominal pain': [],'Muscle weakness of limb': [],
                                    'Headache': [],'Pruritic rash': [],'weakness': [],'Feeling bad': [],
                                    'Eruption of Skin (Rashes)': [],'Vertigo': [],'Numbness of face & limbs': [],
                                    'Breathlessness': [],'Pruritus Ani (Anal itch)': [],'Pruritic rash (Itchy skin eruptions)': [],
                                    'Itchy skin eruptions': [],'Weight loss': [],'Anal itch': [],'Vomiting': [],'Dysuria': [],
                                    'Chest pain': [],'Blister of skin': [],'Dizziness': [],'Edema of lower leg': [],
                                    'Fever with Chills': [],'Left sided abdominal pain': [],'Left/right sided abdominal pain': [],
                                    'Loss of appetite': [],'Rashes': [],'Painful urination': [],'Nose running': [],
                                    'Dyspnoea (Breathlessness)': [],'Cough': [],'Heavy breathing': [],'Hazy vision': [],
                                    'Muscle Pain & Joint Pain': [],'Right sided abdominal pain': [],'Dyspnea': [],'sneezing': []})


    




    def getPrediction(self,selectedTags): 

        for x in selectedTags:
            self.input_values.loc[0,x] = int(selectedTags.get(x))

        #display(self.input_values.to_string())
        #pd.set_option('display.max_columns', None)
        #print(self.input_values)
        yhat_prob = self.model.predict(self.input_values)
        return int(yhat_prob)
        #output_values = self.input_values
        #output_values.loc[0,'Diseases'] = int(yhat_prob)
        #print(int(yhat_prob))
    
        # return the predicted values with the input values
        #return output_values.to_json()


