from django.http import response
from django.http.response import JsonResponse
from django.shortcuts import render
from django.urls import reverse
import random
from .models import DiseaseData, DiseasePredictor, Record, Suggestor
import csv
from fast_autocomplete.misc import read_csv_gen

# Create your views here.
def home(request):
    return render(request, "home/home.html",{"getSuggestionURL":reverse('getSuggestions'),"getDiseasePredictionURL":reverse('getDiseasePrediction'),
    "allTags":Suggestor.getInstance().getWordList() ,"cdsURL":reverse('CDS_Home'),"traiURL":reverse('home')})


def getSuggestions(request):
    
    input_text = request.POST.get("input_text")
    sugg = Suggestor.getInstance().getSuggestion(input_text,3,5)

    out_data = []
    for Ae in sugg:
        for Be in Ae:
            out_data.append(Be)
    
    
    
   
    
    response = {"status":"ok","msg":"ok","data":out_data} 
    return JsonResponse(response)


def getDiseasePrediction(request):
    
    u_input = request.POST

    # predict using model
    #D_id = DiseasePredictor.getInstance().getPrediction(u_input)
    

    #predict using data  
    D_id = getDirectPrediction(u_input)

    if D_id == -1:
        Disease = {
            "name" : "Not Identified",
            "investigations":"Please consult a Doctor",
            "treatment":"Please consult a Doctor"
        }
    else:
        Disease = DiseasePredictor.getInstance().getDeseaseInfo(D_id)
    
    

    sympt = ""
    f = True
    for x in u_input:
        if int(u_input.get(x)) == 1:
            if f :
                sympt = sympt + x
                f =False
            else:
                sympt = sympt + ", " + x


      
    r = Record(DiseaseName=Disease["name"], DiseaseSymptoms=sympt,DiseaseTreatment=Disease["treatment"],DiseaseDiagnosis=Disease["investigations"])
    r.save()

    return JsonResponse({"status":"ok","msg":"ok","data":Disease})




def getDirectPrediction(selectedTags):


        r = DiseaseData.objects.filter(        
            Abdominal_pain = int(selectedTags.get("Abdominal pain")),
            Abnormal_menstrual_cycle = int(selectedTags.get("Abnormal menstrual cycle")),
            Anal_itch = int(selectedTags.get("Anal itch")),
            Blister_of_skin = int(selectedTags.get("Blister of skin")),
            Bloating_symptom = int(selectedTags.get("Bloating symptom")),
            Body_ache = int(selectedTags.get("Body ache")),
            breathing_with_whistling_sound = int(selectedTags.get("breathing with whistling sound")),
            Breathlessness = int(selectedTags.get("Breathlessness")),
            Chest_pain = int(selectedTags.get("Chest pain")),
            Clouded_consciousness = int(selectedTags.get("Clouded consciousness")),
            Cough= int(selectedTags.get("Cough")),
            Dizziness = int(selectedTags.get("Dizziness")),
            Dyspnea = int(selectedTags.get("Dyspnea")),
            Dyspnoea = int(selectedTags.get("Dyspnoea")),
            Dyspnoea_Breathlessness = int(selectedTags.get("Dyspnoea (Breathlessness)")),
            Dysuria = int(selectedTags.get("Dysuria")),
            Edema_of_lower_leg = int(selectedTags.get("Edema of lower leg")),
            Eruption_of_Skin = int(selectedTags.get("Eruption of Skin")),
            Eruption_of_Skin_Rashes = int(selectedTags.get("Eruption of Skin (Rashes)")),
            Eyes_sensitive_to_light = int(selectedTags.get("Eyes sensitive to light")),
            Fatigue = int(selectedTags.get("Fatigue")),
            Feeling_bad = int(selectedTags.get("Feeling bad")),
            Fever = int(selectedTags.get("Fever")),
            Fever_with_Chills = int(selectedTags.get("Fever with Chills")),
            Hazy_vision = int(selectedTags.get("Hazy vision")),
            Headache = int(selectedTags.get("Headache")),
            Heavy_breathing = int(selectedTags.get("Heavy breathing")),
            Increased_frequency_of_urination  = int(selectedTags.get("Increased frequency of urination")),
            Itching_of_skin = int(selectedTags.get("Itching of skin")),
            Itchy_skin_eruptions = int(selectedTags.get("Itchy skin eruptions")),
            Joint_Pain = int(selectedTags.get("Joint Pain")),
            Joint_Swelling = int(selectedTags.get("Joint Swelling")),
            Left_sided_abdominal_pain = int(selectedTags.get("Left sided abdominal pain")),
            Left_right_sided_abdominal_pain = int(selectedTags.get("Left/right sided abdominal pain")),
            Loss_of_appetite = int(selectedTags.get("Loss of appetite")),
            Muscle_Pain_Joint_Pain = int(selectedTags.get("Muscle Pain & Joint Pain")),
            Muscle_weakness_of_limb = int(selectedTags.get("Muscle weakness of limb")),
            Nausea = int(selectedTags.get("Nausea")),
            Negative_automatic_thoughts = int(selectedTags.get("Negative automatic thoughts")),
            Nose_running = int(selectedTags.get("Nose running")),
            Numbness_of_face_and_limbs = int(selectedTags.get("Numbness of face & limbs")),
            Pain_in_Pelvis = int(selectedTags.get("Pain in Pelvis")),
            Painful_urination = int(selectedTags.get("Painful urination")),
            Productive_cough = int(selectedTags.get("Productive cough")),
            Productive_cough_with_sputum = int(selectedTags.get("Productive cough (with sputum)")),
            Pruritic_rash = int(selectedTags.get("Pruritic rash")),
            Pruritic_rash_Itchy_skin_eruptions = int(selectedTags.get("Pruritic rash (Itchy skin eruptions)")),
            Pruritus_Ani = int(selectedTags.get("Pruritus Ani")),
            Pruritus_Ani_Anal_itch = int(selectedTags.get("Pruritus Ani (Anal itch)")),
            Rashes = int(selectedTags.get("Rashes")),
            Rectal_Bleeding = int(selectedTags.get("Rectal Bleeding")),
            Right_sided_abdominal_pain = int(selectedTags.get("Right sided abdominal pain")),
            sneezing = int(selectedTags.get("sneezing")),
            Thoughts_of_self_harm = int(selectedTags.get("Thoughts of self harm")),
            Vertigo = int(selectedTags.get("Vertigo")),
            Vomiting = int(selectedTags.get("Vomiting")),
            weakness = int(selectedTags.get("weakness")),
            Weight_loss = int(selectedTags.get("Weight loss")),
            Wheezing = int(selectedTags.get("Wheezing")),
        )

        if(len(r) == 0):
            return -1

        return r.first().DiseaseData_ID - 1

        print(r)

