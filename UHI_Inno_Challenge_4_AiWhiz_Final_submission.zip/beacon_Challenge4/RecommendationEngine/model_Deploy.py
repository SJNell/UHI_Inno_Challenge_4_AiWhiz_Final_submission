#!/usr/bin/env python
# coding: utf-8

# In[ ]:


# for pickling
import pickle
import pandas as pd
from config.settings import DISEASE_MODEL_PICKLE_FILE_PATH
import numpy as np

def predict():
    model_pkl_file_path =DISEASE_MODEL_PICKLE_FILE_PATH
    # We expect one argument, the hostname without TLD.
    # Loading the saved KNN model pickle file
    load_model_pkl = open(model_pkl_file_path, 'rb')
    model = pickle.load(load_model_pkl)
    
    input_values = pd.DataFrame({'Thoughts of self harm': [],'Eruption of Skin': [],'breathing with whistling sound': [],
                                 'Negative automatic thoughts': [],'Dyspnoea': [],'Increased frequency of urination': [],
                                 'Wheezing': [],'Rectal Bleeding': [],'Nausea': [],'Abnormal menstrual cycle': [],
                                 'Clouded consciousness': [],'Fatigue': [],'Body ache': [],'Productive cough': [],
                                 'Productive cough (with sputum)': [],'Fever': [],'Bloating symptom': [],
                                 'Eyes sensitive to light': [],'Pain in Pelvis': [],'Pruritus Ani': [],'Joint Pain': [],
                                 'Joint Swelling': [],'Itching of skin': [],'Abdominal pain': [],'Muscle weakness of limb': [],
                                 'Headache': [],'Pruritic rash': [],'weakness': [],'Feeling bad': [],
                                 'Eruption of Skin (Rashes)': [],'Vertigo': [],'Numbness of face & limbs': [],
                                 'Breathlessness': [],'Pruritus Ani (Anal itch)': [],'Pruritic rash (Itchy skin eruptions)': [],
                                 'Itchy skin eruptions': [],'Weight loss': [],'Anal itch': [],'Vomiting': [],'Dysuria': [],
                                 'Chest pain': [],'Blister of skin': [],'Dizziness': [],'Edema of lower leg': [],
                                 'Fever with Chills': [],'Left sided abdominal pain': [],'Left/right sided abdominal pain': [],
                                 'Loss of appetite': [],'Rashes': [],'Painful urination': [],'Nose running': [],
                                 'Dyspnoea (Breathlessness)': [],'Cough': [],'Heavy breathing': [],'Hazy vision': [],
                                 'Muscle Pain & Joint Pain': [],'Right sided abdominal pain': [],'Dyspnea': [],'sneezing': []})
    input_values.loc[0,:] = int(0)
    print(input_values)
    
    input_values.loc[0,'Abnormal menstrual cycle'] = int(1)
    input_values.loc[0,'Pain in Pelvis'] = int(1)
    
    yhat_prob = model.predict(input_values)
    output_values = input_values
    output_values.loc[0,'Diseases'] = int(yhat_prob)
    print(yhat_prob)
    
    # return the predicted values with the input values
    return output_values.to_json()

if __name__ == "__main__":
    # Make sure flask uses the port we reserved
    predict()


# In[ ]:


# for pickling
import pandas as pd
import numpy as np
#from sklearn_pmml_model.ensemble import PMMLForestClassifier
from sklearn2pmml import sklearn2pmml
from sklearn_pandas import DataFrameMapper
from pypmml import Model
from os import path

def predict():
    model_pmml_file_path ="C:/aiWhiz/UHI-NHA/Data/NHA_Data/RF_PMML.pmml"
    # We expect one argument, the hostname without TLD.
    # Loading the saved KNN model pickle file
    # model = Model.load(model_pmml_file_path)
    
    input_values = pd.DataFrame({'Thoughts of self harm': [],'Eruption of Skin': [],'breathing with whistling sound': [],
                                 'Negative automatic thoughts': [],'Dyspnoea': [],'Increased frequency of urination': [],
                                 'Wheezing': [],'Rectal Bleeding': [],'Nausea': [],'Abnormal menstrual cycle': [],
                                 'Clouded consciousness': [],'Fatigue': [],'Body ache': [],'Productive cough': [],
                                 'Productive cough (with sputum)': [],'Fever': [],'Bloating symptom': [],
                                 'Eyes sensitive to light': [],'Pain in Pelvis': [],'Pruritus Ani': [],'Joint Pain': [],
                                 'Joint Swelling': [],'Itching of skin': [],'Abdominal pain': [],'Muscle weakness of limb': [],
                                 'Headache': [],'Pruritic rash': [],'weakness': [],'Feeling bad': [],
                                 'Eruption of Skin (Rashes)': [],'Vertigo': [],'Numbness of face & limbs': [],
                                 'Breathlessness': [],'Pruritus Ani (Anal itch)': [],'Pruritic rash (Itchy skin eruptions)': [],
                                 'Itchy skin eruptions': [],'Weight loss': [],'Anal itch': [],'Vomiting': [],'Dysuria': [],
                                 'Chest pain': [],'Blister of skin': [],'Dizziness': [],'Edema of lower leg': [],
                                 'Fever with Chills': [],'Left sided abdominal pain': [],'Left/right sided abdominal pain': [],
                                 'Loss of appetite': [],'Rashes': [],'Painful urination': [],'Nose running': [],
                                 'Dyspnoea (Breathlessness)': [],'Cough': [],'Heavy breathing': [],'Hazy vision': [],
                                 'Muscle Pain & Joint Pain': [],'Right sided abdominal pain': [],'Dyspnea': [],'sneezing': []})
    input_values.loc[0,:] = int(0)
    print(input_values)
    
    input_values.loc[0,'Abnormal menstrual cycle'] = int(1)
    input_values.loc[0,'Pain in Pelvis'] = int(1)
    
    #model = PMMLBaseClassifier(pmml=model_pmml_file_path)
    #default_mapper = DataFrameMapper([(i, None) for i in input_values.columns + ['Diseases']])
    #model = sklearn2pmml(estimator=input_values, mapper=default_mapper, pmml=model_pmml_file_path)
    yhat_prob = model.predict(input_values)
    
    print(yhat_prob)
    output_values = input_values
    output_values.loc[0,'Diseases'] = int(yhat_prob)
    print(yhat_prob)
    
    # return the predicted values with the input values
    return output_values.to_json()

if __name__ == "__main__":
    # Make sure flask uses the port we reserved
    predict()


# In[ ]:




