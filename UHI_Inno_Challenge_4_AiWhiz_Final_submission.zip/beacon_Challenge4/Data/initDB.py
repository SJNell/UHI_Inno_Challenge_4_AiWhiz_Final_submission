
from search.models import DiseaseData, Record
Record.objects.all().delete()
'''
return 0
DiseaseData(
    DiseaseName="Pulmonary Tuberculosis",Fever=1,Weight_loss=1,Cough=1,Chest_pain=1
).save()

DiseaseData(
    DiseaseName="Asthma",Dyspnea=1,Breathlessness=1,Chest_pain=1,Cough=1,Wheezing=1,Heavy_breathing=1,breathing_with_whistling_sound=1,
).save()


DiseaseData(
    DiseaseName="Cerebrovascular Accident (Stroke)",Muscle_weakness_of_limb=1,
   Numbness_of_face_and_limbs=1,Clouded_consciousness=1,Dizziness=1,Vertigo=1,
).save()

DiseaseData(
    DiseaseName="Common cold/Influenza", Fever=1,Body_ache=1,Cough=1,Nose_running=1,sneezing=1
).save()
DiseaseData(
    DiseaseName="Diarrhea", Abdominal_pain=1,Nausea=1,Bloating_symptom=1,Fever=1
).save()

DiseaseData(
    DiseaseName="Dengue", Fever=1,Headache=1,Muscle_Pain_Joint_Pain=1,Loss_of_appetite=1,
).save()

DiseaseData(
    DiseaseName="Pneumonia", Chest_pain=1,Productive_cough_with_sputum=1,Productive_cough=1,Nausea=1,Fever_with_Chills=1
    ,Dyspnoea_Breathlessness=1,Dyspnoea=1,Breathlessness=1
).save()
DiseaseData(
    DiseaseName="Kidney stones", Left_right_sided_abdominal_pain=1,Left_sided_abdominal_pain=1
    ,Right_sided_abdominal_pain=1,Dysuria=1,Nausea=1,Vomiting=1,Increased_frequency_of_urination=1,
    Painful_urination=1
).save()
DiseaseData(
    DiseaseName="Cirrhosis of Liver", Loss_of_appetite=1,Fatigue=1,Nausea=1,Edema_of_lower_leg=1
).save()
DiseaseData(
    DiseaseName="Hemorrhoids", Rectal_Bleeding=1,Pruritus_Ani_Anal_itch=1,Pruritus_Ani=1,Anal_itch=1,
    ).save()

DiseaseData(
    DiseaseName="Psoriasis", Eruption_of_Skin_Rashes=1,Eruption_of_Skin=1,Rashes=1
    ,Pruritic_rash_Itchy_skin_eruptions=1,Pruritic_rash=1,Itchy_skin_eruptions=1,
    Itching_of_skin =1
).save()
DiseaseData(
    DiseaseName="Chicken pox", Blister_of_skin=1,Fever=1,Loss_of_appetite=1,Headache=1
).save()
DiseaseData(
    DiseaseName="Anxiety/ Depressive disorder", Thoughts_of_self_harm=1,Feeling_bad=1,Negative_automatic_thoughts=1
).save()


DiseaseData(
    DiseaseName="Rheumatoid arthritis", Fever=1,Fatigue=1,weakness=1,Joint_Pain=1,Joint_Swelling=1
    ,
).save()
DiseaseData(
    DiseaseName="Uterine Fibroid", Abnormal_menstrual_cycle=1,Pain_in_Pelvis=1
).save()


DiseaseData(
    DiseaseName="Cataract", Hazy_vision=1,Eyes_sensitive_to_light=1
).save()

	'''