#!/usr/bin/env python
# coding: utf-8

# In[ ]:


# List of all the required libraries
import pandas as pd
from config.settings import DISEASE_DATA_FILE
import numpy as np
from numpy import array
import re
# import all the required Model libraries
from sklearn.metrics import mean_absolute_error
from sklearn.metrics import mean_squared_error
from sklearn.preprocessing import StandardScaler
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import LabelEncoder

from sklearn.tree import DecisionTreeClassifier
from sklearn.neighbors import KNeighborsClassifier
from sklearn.ensemble import ExtraTreesClassifier, RandomForestClassifier
from sklearn.ensemble import GradientBoostingClassifier
from sklearn.ensemble import AdaBoostClassifier
from sklearn.ensemble import BaggingClassifier
# for pickling
import pickle

# Hand picked models to train
BAGGINGCLASSIFIER = "baggingClassifier"
XGBRFCLASSIFIER = "xgbrfClassifier"
scaler = StandardScaler()

def baggingClassifier(x_train, y_train):
    model = BaggingClassifier(n_estimators=100)
    model.fit(x_train, y_train)
    return model


def xgbrfClassifier(x_train, y_train):
    model = XGBRFClassifier(n_estimators=100)
    model.fit(x_train, y_train)
    return model

# Train Model to execute the Model
def trainModel(model, x_train, y_train):
    if model == BAGGINGCLASSIFIER:
        return baggingClassifier(x_train, y_train)
    elif model == XGBRFCLASSIFIER:
        return xgbrfClassifier(x_train, y_train)
    
# Function for Error Calculations
def calculate_error(y_test, predicted):
    return mean_absolute_error(y_test, predicted)

def dt_inplace(df):
    for col in df.columns[df.dtypes == 'object']:  # don't cnvt num
        try:
            df[col] = pd.to_datetime(df[col])
        except (ParserError, ValueError):  # Can't cnvrt some
            pass  # ...so leave whole column as-is unconverted
    return df

# Predict function to execute the Model predictions
def predict_(m, x_test):
    return pd.Series(m.predict(x_test))

def output_ResultData(model, y_test, predicted_value):
    outputData = pd.DataFrame({'Actual_Value': [], 'Predicted_Value': [], 'Prediction_Error': [],
                               'Abs.Predicted_Difference': [], 'Prediction_Error%':[]})
    print(y_test)
    print(predicted_value)
    for val in range(0, len(y_test)):
        print(int(y_test[val]))
        outputData.loc[val, 'Actual_Value'] = y_test[val]
        predVal = round(int(predicted_value[val]))
        outputData.loc[val, 'Predicted_Value'] = predVal
        prediction_Error = y_test[val] - predVal
        outputData.loc[val, 'Prediction_Error'] = prediction_Error
        outputData.loc[val, 'Abs.Predicted_Difference'] = abs(prediction_Error)        
        outputData.loc[val, 'Prediction_Error%'] = np.round((prediction_Error / y_test[val]) * 100, 2)
    return outputData

def featurePreparation(dfData, colPredict):
    # Get all the relevant features
    features = list(set(list(dfData.columns)))
    print(features)
    print(colPredict)
    features = list(set(list(features)) - set(colPredict))
    print(features)
    dfData = dfData[features]
    return features

def dataPreparation(dfData):
    # Get all the relevant features
    features = list(set(list(dfData.columns)))
    num_features = [col for col in dfData.columns if
                    ((dfData.dtypes[col] == 'float64') | (dfData.dtypes[col] == 'int64'))]
    dfData[num_features] = dfData[num_features].fillna(0)
    cat_features = [col for col in dfData.columns if dfData.dtypes[col] == 'object']
    # Impute categorical missing values with -9999
    dfData[cat_features] = dfData[cat_features].fillna(value=-9999)
    if len(cat_features) > 0:
        # create label encoders for categorical features
        for var in cat_features:
            number = LabelEncoder()
            dfData[var] = number.fit_transform(dfData[var].astype('str'))
    return dfData


# In[ ]:


# List of all the required libraries
import pandas as pd
import numpy as np
from numpy import array
import re
from sklearn.utils import resample

# import all the required Model libraries
from sklearn.ensemble import ExtraTreesRegressor, RandomForestRegressor
from xgboost import XGBRegressor, XGBRFClassifier

def mainProgram():
    filePath = DISEASE_DATA_FILE
    #filePath = "C:/aiWhiz/UHI-NHA/Data/NHA_Data/Hackathon-Challenge4-Data_Latest.xlsx"    
    # Get the values from the Service Object
    colPredict = 'Diseases'
    dfData = pd.read_excel(filePath)
    response = ""
    print("-----Initial Cleansing Operations Starts-----")
    dfData = dfData.drop_duplicates(keep='first')
    colList = dfData.columns.values
    # Delete all Null / Totally Null Rows from the Data Set
    nullRows = dfData.index[dfData.isnull().all(axis=1)]
    print("All Null Rows index is as below")
    print(nullRows)
    dfData.drop(nullRows, inplace=True)
    # Delete all Null / Totally Null Columns from the Data Set
    nullCols = [i for i in dfData.columns if dfData[i].isnull().sum() >= len(dfData)]
    print("All Null Column names are as below")
    print(nullCols)
    dfData = dfData.drop(nullCols, axis=1).reset_index(drop=True)
    print("-----Initial Cleansing Operations Ends-----")
    model = BAGGINGCLASSIFIER
    print(model)
    
    dfData = dataPreparation(dfData)
    dfData = resample(dfData, replace=True, n_samples=10000, random_state=42)

    print("-----Machine Learning operations Starts -----")
    trainingData, testData = train_test_split(dfData, train_size=0.10)
    trainingData = trainingData.reset_index(drop=True)
    testData = testData.reset_index(drop=True)
    
    features = featurePreparation(dfData, colPredict)
    print(features)
    
    predicted_value = 0
    y_train = dfData[colPredict].reset_index(drop=True)
    y_test = testData[colPredict].reset_index(drop=True)
    print(features)
    len(features)
    X_train = dfData[list(features)]    
    X_test = testData[list(features)]
    if colPredict in X_train.columns:
        X_train = X_train.drop(colPredict, axis=1).reset_index(drop=True)
    if colPredict in X_test.columns:
        X_test = X_test.drop(colPredict, axis=1).reset_index(drop=True)
    # Call trainModel function to training the selected models
    fit_model = trainModel(model, X_train, y_train)
    predicted_value = predict_(fit_model, X_test)
    print(predicted_value)
    pickling(fit_model)
    #create_pmml(X_train, y_train)
    #print(y_test)
    #outputData = output_ResultData(model, y_test, predicted_value)    
    #print("-----Machine Learning operations Ends and Saving your Results -----")
    # Produce the Output Result file
    #outputData.to_csv("C:/aiWhiz/UHI-NHA/Data/NHA_Data/NHA_Model_Results.csv", index=False)
    # Generate Output Summary Report


# In[ ]:


if __name__ == "__main__":
    mainProgram()


# In[ ]:


def pickling(fit_model):
    # Dump the trained KNN model to a Python Pickled file
    model_pkl_filename = "C:/aiWhiz/UHI-NHA/Data/NHA_Data/model_pkl_file.pkl"
    # Open the file to save as pkl file
    model_pkl = open(model_pkl_filename, 'wb')
    pickle.dump(fit_model, model_pkl)
    # Close the pickle instances
    model_pkl.close()


# In[ ]:




