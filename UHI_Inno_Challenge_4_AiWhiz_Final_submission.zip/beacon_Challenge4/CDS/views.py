import os
from search.models import Record
from django.shortcuts import render
from django.conf import settings
from django.core.files.storage import FileSystemStorage
from detect_delimiter import detect
import pandas as pd
from django.http import JsonResponse
from django.urls import reverse

# Create your views here.

def Gethistory(request):
    rs =  Record.objects.all().order_by('-Record_ID')[:10]
    return render(request, "cds/history.html",{"cdsGetColumnsURL":reverse("cdsGetColumns"),"cdsGetExtractedDataURL":reverse("cdsGetExtractedData"),
    "cdsURL":reverse('CDS_Home'),"traiURL":reverse('home'),"rec":rs
    })

def CDS_Home(request):
    return render(request, "cds/cds.html",{"cdsGetColumnsURL":reverse("cdsGetColumns"),"cdsGetExtractedDataURL":reverse("cdsGetExtractedData"),
    "cdsURL":reverse('CDS_Home'),"traiURL":reverse('home'),"historyURL":reverse('history')
    })


def getColumns(request):

    uploadedFile = request.FILES['FILE']

    fs = FileSystemStorage()          
    fp = os.path.join(settings.MEDIA_ROOT,"tmp",uploadedFile.name)
    filename = fs.save(fp,uploadedFile)
    filepath = os.path.join(settings.MEDIA_ROOT,filename)
    Filetype = os.path.splitext(filepath)[1]


    dfdata=None
    if Filetype == ".csv" or Filetype == ".txt":
        with open(filepath) as processingfile:
            firstline = processingfile.readline()
        processingfile.close()
        delimiter = detect(firstline)# detect delimiter             
        dfdata = pd.read_csv(filepath,sep = delimiter)

    elif Filetype == ".xls":
        dfdata = pd.read_excel(filepath)
    elif Filetype == ".xlsx":
        dfdata = pd.read_excel(filepath,engine='openpyxl')
        
    else:
        data = {"status":"error","error":"not supported file"}
        return JsonResponse(data)

    if dfdata.empty:
        data = {"status":"error","error":"File is corrupted."}
        return JsonResponse(data)

    for col in dfdata:
                if (col.lower() == "id"):
                    dfdata = dfdata.drop(col, axis=1).reset_index(drop=True)
    
    dfdata = dt_inplace(dfdata)  
    data = getIntDateDatatype(dfdata)    
    response = {"mgs":"ok","status":"ok","data":data,"error":"none"}
    fs.delete(filename)
    return JsonResponse(response)

def GetExtractedData(request):
    uploadedFile = request.FILES['FILE']
    Slabel = request.POST.get('Slabel')
    Snumber = request.POST.get('Snumber')

    fs = FileSystemStorage()          
    fp = os.path.join(settings.MEDIA_ROOT,"tmp",uploadedFile.name)
    filename = fs.save(fp,uploadedFile)
    filepath = os.path.join(settings.MEDIA_ROOT,filename)
    Filetype = os.path.splitext(filepath)[1]


    dfdata=None
    if Filetype == ".csv" or Filetype == ".txt":
        with open(filepath) as processingfile:
            firstline = processingfile.readline()
        processingfile.close()
        delimiter = detect(firstline)# detect delimiter             
        dfdata = pd.read_csv(filepath,sep = delimiter)

    elif Filetype == ".xls":
        dfdata = pd.read_excel(filepath)
    elif Filetype == ".xlsx":
        dfdata = pd.read_excel(filepath,engine='openpyxl')
        
    else:
        data = {"status":"error","error":"not supported file"}
        return JsonResponse(data)

    if dfdata.empty:
        data = {"status":"error","error":"File is corrupted."}
        return JsonResponse(data)

    for col in dfdata:
                if (col.lower() == "id"):
                    dfdata = dfdata.drop(col, axis=1).reset_index(drop=True)
    
    dfdata = dt_inplace(dfdata)  
    number = dfdata[Snumber].values.tolist()
    label = dfdata[Slabel].values.tolist()
    data = {"number":number,"label":label,"labelName":Slabel,"numberName":Snumber}  
    response = {"mgs":"ok","status":"ok","data":data,"error":"none"}
    fs.delete(filename)
    return JsonResponse(response)

def getIntDateDatatype(dfData):
    numCol=[]
    timeCol=[]
    for column in dfData.columns:
        ty = pd.api.types.infer_dtype(dfData[column])
        if ty == 'integer' or ty == 'floating' or ty == 'mixed-integer-float' or ty == 'decimal':
            numCol.append(column)
        if ty == 'datetime64' or ty == 'datetime' or ty == 'date' or ty == 'string':
            timeCol.append(column)
    data = {"time":timeCol,"number":numCol}
 
    return data


def dt_inplace(df):
    for col in df.columns[df.dtypes=='object']: #don't cnvt num
        try:
            df[col]=pd.to_datetime(df[col])
        except: #Can't cnvrt some
            pass # ...so leave whole column as-is unconverted
    return df

