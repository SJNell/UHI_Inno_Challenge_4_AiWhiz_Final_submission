from os import name
from django.urls import path
from . import views
urlpatterns = [
    path('cds', views.CDS_Home,name="CDS_Home"),
    path('cds/getColumns',views.getColumns,name="cdsGetColumns"),
    path('cds/GetExtractedData',views.GetExtractedData,name="cdsGetExtractedData"),
    path('cds/history',views.Gethistory,name="history")
]